apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: {{ include "arpa.fullname" . }}
  labels:
    {{- include "arpa.labels" . | nindent 4 }}
    {{- with .Values.labels }}
    {{- toYaml . | nindent 4 }}
    {{- end}}
spec:
  replicas: {{ .Values.replicaCount }}
  selector:
    matchLabels:
      {{- include "arpa.selectorLabels" . | nindent 6 }}
        {{- with .Values.labels }}
        {{- toYaml . | nindent 6 }}
        {{- end}}
  template:
    metadata:
      {{- with .Values.podAnnotations }}
      annotations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      labels:
        app: {{ include "arpa.fullname" . }}
        {{- include "arpa.selectorLabels" . | nindent 8 }}
        {{- with .Values.labels }}
        {{- toYaml . | nindent 8 }}
        {{- end}}
    spec:
      {{- with .Values.imagePullSecrets }}
      imagePullSecrets:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      serviceAccountName: {{ .Values.serviceAccount.name | default (include "arpa.fullname" .) }}
      securityContext:
        {{- toYaml .Values.podSecurityContext | nindent 8 }}
      containers:
        - name: node-shell
          {{- with .Values.nodeShell.command }}
          command:
          {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with .Values.nodeShell.args }}
          args:
          {{- toYaml . | nindent 12 }}
          {{- end }}
          securityContext:
            {{- toYaml .Values.securityContext | nindent 12 }}
          image: "{{ .Values.nodeShell.image.repository }}:{{ .Values.nodeShell.image.tag | default .Chart.AppVersion }}"
          imagePullPolicy: {{ .Values.nodeShell.image.pullPolicy }}
          {{- if .Values.lifecycleHooks }}
          lifecycle:
          {{- toYaml .Values.nodeShell.lifecycleHooks | nindent 12 }}
          {{- end }}
          resources:
            {{- toYaml .Values.nodeShell.resources | nindent 12 }}
          volumeMounts:
          {{- with .Values.node.volumeMounts }}
          {{- toYaml . | nindent 12 }}
          {{- end }}
          env:
            {{- toYaml .Values.node.env | nindent 12 }}
        - name: node
          {{- with .Values.node.command }}
          command:
          {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with .Values.node.args }}
          args:
          {{- toYaml . | nindent 12 }}
          {{- end }}
          securityContext:
            {{- toYaml .Values.securityContext | nindent 12 }}
          image: "{{ .Values.node.image.repository }}:{{ .Values.node.image.tag | default .Chart.AppVersion }}"
          imagePullPolicy: {{ .Values.node.image.pullPolicy }}
          ports:
          {{- toYaml $.Values.node.ports | nindent 10 }}
          {{- if .Values.lifecycleHooks }}
          lifecycle:
          {{- toYaml .Values.node.lifecycleHooks | nindent 12 }}
          {{- end }}
          {{- if .Values.node.livenessProbe }}
          livenessProbe:
            {{- toYaml .Values.node.livenessProbe | nindent 12 }}
          {{- end }}
          {{- if .Values.node.readinessProbe }}
          readinessProbe:
            {{- toYaml .Values.node.readinessProbe | nindent 12 }}
          {{- end }}
          resources:
            {{- toYaml .Values.node.resources | nindent 12 }}
          volumeMounts:
          {{- with .Values.node.volumeMounts }}
          {{- toYaml . | nindent 12 }}
          {{- end }}
          env:
            {{- toYaml .Values.node.env | nindent 12 }}
        {{- if .Values.cloudwatch.enabled }}
        - name: cloudwatch
          {{- with .Values.cloudwatch.command }}
          command:
          {{- toYaml . | nindent 12 }}
          {{- end }}
          {{- with .Values.cloudwatch.args }}
          args:
          {{- toYaml . | nindent 12 }}
          {{- end }}
          securityContext:
            {{- toYaml .Values.securityContext | nindent 12 }}
          image: "{{ .Values.cloudwatch.image.repository }}:{{ .Values.cloudwatch.image.tag | default .Chart.AppVersion }}"
          imagePullPolicy: {{ .Values.cloudwatch.image.pullPolicy }}
          {{- if .Values.lifecycleHooks }}
          lifecycle:
          {{- toYaml .Values.cloudwatch.lifecycleHooks | nindent 12 }}
          {{- end }}
          {{- if .Values.cloudwatch.livenessProbe }}
          livenessProbe:
            {{- toYaml .Values.cloudwatch.livenessProbe | nindent 12 }}
          {{- end }}
          {{- if .Values.cloudwatch.readinessProbe }}
          readinessProbe:
            {{- toYaml .Values.cloudwatch.readinessProbe | nindent 12 }}
          {{- end }}
          resources:
            {{- toYaml .Values.cloudwatch.resources | nindent 12 }}
          volumeMounts:
          {{- with .Values.cloudwatch.volumeMounts }}
          {{- toYaml . | nindent 12 }}
          {{- end }}
          env:
            {{- toYaml .Values.cloudwatch.env | nindent 12 }}
        {{- end }}
      volumes:
          {{- with .Values.volumes }}
          {{- toYaml . | nindent 8 }}
          {{- end }}
        - name: config
          configMap:
            name: {{ include "arpa.fullname" . }}-config

      {{- with .Values.nodeSelector }}
      nodeSelector:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.affinity }}
      affinity:
        {{- toYaml . | nindent 8 }}
      {{- end }}
      {{- with .Values.tolerations }}
      tolerations:
        {{- toYaml . | nindent 8 }}
      {{- end }}
